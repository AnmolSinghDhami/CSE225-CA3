package com.example.ca3.CustomViews;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.content.res.ResourcesCompat;

import com.example.ca3.R;

import static android.content.ContentValues.TAG;

public class CustomEditText extends AppCompatEditText {

    Drawable clearButton, clearButtonIn;

    public CustomEditText(Context context) {
        super(context);
        init();
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public void init(){
        clearButton = ResourcesCompat.getDrawable(getResources(), R.drawable.ic_clear_black_24dp, null);
        clearButtonIn = ResourcesCompat.getDrawable(getResources(), R.drawable.ic_clear_opackblack_24dp, null);

        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                showButton();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                Log.d(TAG, "afterTextChanged: getText "+getText().toString());
                if (getText().toString().equals("")){
                    hideButton();
                    Log.d(TAG, "afterTextChanged: INSIDE");
                }
            }
        });

        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                float clearButtonPos;
                Boolean isClicked = false;

                clearButtonPos = getWidth() - getPaddingEnd() - clearButton.getIntrinsicWidth();

                if(motionEvent.getX() > clearButtonPos){
                    isClicked = true;
                }
                if(isClicked){
                    getText().clear();
                }
                return false;
            }
        });
    }

    public void showButton(){
        setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, clearButton, null);
    }

    public void hideButton(){
        setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, clearButtonIn, null);
    }
}
