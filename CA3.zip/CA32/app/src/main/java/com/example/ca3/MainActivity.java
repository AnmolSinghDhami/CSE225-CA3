package com.example.ca3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void loadQuestion(View v){
        Intent i;
        switch (v.getId()){
            case R.id.q1:
                i = new Intent(this, Q1.class);
                startActivity(i);
                break;
            case R.id.q4:
                i = new Intent(this, Q4.class);
                startActivity(i);
                break;
            case R.id.q5:
                i = new Intent(this, Q5.class);
                startActivity(i);
                break;
        }
    }
}
