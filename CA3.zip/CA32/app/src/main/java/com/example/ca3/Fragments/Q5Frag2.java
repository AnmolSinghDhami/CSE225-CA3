package com.example.ca3.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ca3.R;

public class Q5Frag2 extends Fragment {

    static TextView frag2Text;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_q5_frag2, container, false);
        frag2Text = v.findViewById(R.id.frag2Text);

        return v;
    }

    public static void updateText(String a){
        frag2Text.setText(a);
    }
}
