package com.example.ca3.Fragments;

import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ca3.R;

import static android.content.ContentValues.TAG;

public class ScreenSlideFragment extends Fragment {

    ImageView image;
    TextView text;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_screen_slide, container, false);

        image = v.findViewById(R.id.image);
        text = v.findViewById(R.id.text);

        int scaleType = getArguments().getInt("scaleType");
        boolean selected = getArguments().getBoolean("selected");
        Uri imageUri;
        if(selected){
            imageUri = Uri.parse(getArguments().getString("uri"));
            image.setImageURI(imageUri);
        }
        switch (scaleType){
            case 1:
                text.setText("CENTER");
                image.setScaleType(ImageView.ScaleType.CENTER);
                break;
            case 2:
                text.setText("CENTER_CROP");
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                break;
            case 3:
                text.setText("CENTER_INSIDE");
                image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                break;
            case 4:
                text.setText("FIT_CENTER");
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                break;
            case 5:
                text.setText("FIT_END");
                image.setScaleType(ImageView.ScaleType.FIT_END);
                break;
            case 6:
                text.setText("FIT_START");
                image.setScaleType(ImageView.ScaleType.FIT_START);
                break;
            case 7:
                text.setText("FIT_XY");
                image.setScaleType(ImageView.ScaleType.FIT_XY);
                break;
            case 8:
                text.setText("MATRIX");
                image.setScaleType(ImageView.ScaleType.MATRIX);
                break;
        }

        return v;
    }
}
