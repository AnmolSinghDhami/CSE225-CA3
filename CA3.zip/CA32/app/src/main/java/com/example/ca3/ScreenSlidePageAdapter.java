package com.example.ca3;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.ca3.Fragments.ScreenSlideFragment;

public class ScreenSlidePageAdapter extends FragmentStatePagerAdapter {

    private int[] arr = {1, 2, 3, 4, 5, 6, 7, 8};
    boolean selected = false;
    Uri imageUri;

    public ScreenSlidePageAdapter(FragmentManager fm) {
        super(fm);
    }

    public ScreenSlidePageAdapter(FragmentManager fm, Uri imageUri){
        super(fm);
        this.selected = true;
        this.imageUri = imageUri;
    }

    @Override
    public Fragment getItem(int position) {

        ScreenSlideFragment frag = new ScreenSlideFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("scaleType", arr[position]);
        bundle.putBoolean("selected", selected);
        if (selected){
            bundle.putString("uri", imageUri.toString());
        }
        frag.setArguments(bundle);
        return frag;
    }

    @Override
    public int getCount() {
        return Q1.NUM_PAGES;
    }
}
