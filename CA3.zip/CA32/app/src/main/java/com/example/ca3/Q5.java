package com.example.ca3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.ca3.Fragments.Q5Frag1;
import com.example.ca3.Fragments.Q5Frag2;

public class Q5 extends AppCompatActivity implements Q5Frag1.Send {

    Fragment frag2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q5);

        frag2 = new Q5Frag2();
    }

    @Override
    public void onSend(String a) {
        Q5Frag2.updateText(a);
    }
}
