package com.example.ca3.CustomViews;

import android.content.Context;
import android.icu.text.UnicodeSetSpanner;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;

import static android.content.ContentValues.TAG;

public class CustomButton extends AppCompatButton {

    Context ct;

    public CustomButton(Context context) {
        super(context);
        init(context);
    }

    public CustomButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public void init(final Context ct){
        this.ct = ct;
        setOnHoverListener(new OnHoverListener() {
            @Override
            public boolean onHover(View view, MotionEvent motionEvent) {
                Log.d(TAG, "onHover: HOVERING!");
                Toast.makeText(ct, "Hover", Toast.LENGTH_SHORT).show();
                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_HOVER_ENTER:
                        Log.d(TAG, "onHover: hover");
                        break;
                    case MotionEvent.ACTION_HOVER_EXIT:
                        Log.d(TAG, "onHover: hover exit");
                        break;
                }
                return false;
            }
        });
    }
}
